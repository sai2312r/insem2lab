package com.example.ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiParameterEndpointTestingApplication {

    public static void main(String[] args) {
        SpringApplication.run(MultiParameterEndpointTestingApplication.class, args);
    }
}
