package com.example.ms;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdditionController {

    @GetMapping(value = "/ms1/add", produces = "text/plain")
    public String add(@RequestParam("a") int a, @RequestParam("b") int b) {
        int sum = a + b;
        return "MS 1.1 - Addition = " + sum;
    }
}
