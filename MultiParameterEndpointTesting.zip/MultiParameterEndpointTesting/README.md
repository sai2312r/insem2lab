# Multi-Parameter Endpoint Unit Testing

A ready-to-run Spring Boot Maven project for the MockMvc task.

## Requirements
- JDK 17 or later
- Maven 3.6+ (or use the Maven integration in STS4/Eclipse)
- Internet connection on the first build so Maven can download dependencies

## Import into STS4 / Eclipse
1. Extract this ZIP file.
2. Open STS4 / Eclipse.
3. Select **File → Import → Maven → Existing Maven Projects**.
4. Browse to the extracted `MultiParameterEndpointTesting` folder.
5. Select the project and click **Finish**.
6. Wait for Maven dependencies to finish downloading.

## Run the JUnit test
- Open `src/test/java/com/example/ms/AdditionControllerTest.java`.
- Right-click the file → **Run As → JUnit Test**.
- The test should pass with a green JUnit bar.

Or run from a terminal in the project folder:

```bash
mvn test
```

## Run the application
```bash
mvn spring-boot:run
```

Then open this URL:

`http://localhost:8080/ms1/add?a=-5&b=5`

Expected plain-text response:

`MS 1.1 - Addition = 0`

## Viva answers

**1. How does testing edge cases like negative parameters prevent regression issues in REST endpoints?**

It verifies that the endpoint handles boundary and unusual inputs correctly. This catches defects early and ensures later code changes do not break previously working behavior.

**2. What assertion methods are used in MockMvc to evaluate plain-text versus JSON response content?**

- Plain text: `content().string("expected text")`
- JSON: `content().json("{\"key\":\"value\"}")`
- HTTP status: `status().isOk()`
- Content type, when needed: `content().contentType("text/plain")`

This project asserts both HTTP 200 and the exact plain-text response.
